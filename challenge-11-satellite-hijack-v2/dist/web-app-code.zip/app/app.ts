#!/usr/bin/env bun
import { readFileSync, existsSync } from "fs";
import { join } from "path";
import { Elysia, t } from "elysia";
import { staticPlugin } from "@elysiajs/static";
import { file, type BunFile } from "bun";
import { html } from "@elysiajs/html";
import { jwt } from "@elysiajs/jwt";
import * as cheerio from "cheerio";

const newUser = (max: number = 999_999_999) => {
  return Math.floor(Math.random() * max).toString();
};

const hashed = (data: string) => Bun.hash(data).toString();

let secretCounter = 0;
const secretKeys = [
  "18085187822509996292",
  "17378994655103058774",
  "8479454221367048344",
  "13130894127890922839",
  "11810248113170005508",
  "7138778794233964739",
  "4692270384726848843",
  "16708230765050951225",
  "3317326574378982295",
];

const flag = (() => {
  const flagPath = join(import.meta.dir, "flag.txt");
  if (existsSync(flagPath)) {
    return readFileSync(flagPath, "utf8").trim();
  }
  return "CTFLIB{example-flag-for-testing}";
})();

const app = new Elysia()
  .use(
    staticPlugin({
      assets: "public",
      prefix: "/",
    })
  )
  .use(html())
  .use(
    jwt({
      name: "jwt",
      secret: "s4t3ll1t3z3r0", // should I use an environmental variable here?
    })
  )
  .decorate("layout", () => file("pages/layout.html"))
  .decorate("home", () => file("pages/home.html"))
  .decorate("satellites", () => file("pages/satellites.html"))
  .decorate("salad", () => file("pages/salad.html"))
  .decorate("tracking", () => file("pages/tracking.html"))
  .decorate("system", () => file("pages/system.html"))
  .decorate("about", () => file("pages/about.html"))
  .decorate("flagPage", () => file("pages/flag.html"));

app.guard(
  {
    headers: t.Object({
      user: t.Optional(t.String()),
    }),
    cookie: t.Cookie({
      token: t.Optional(t.String()),
    }),
  },
  (app) =>
    app
      .resolve(async ({ headers, cookie, jwt }) => {
        let userId = newUser();
        let authorized = false;
        let keyHash = secretKeys[secretCounter % secretKeys.length];

        if (headers.user) {
          const [user, key] = headers.user.split(":");

          if (
            hashed(`${hashed(user)}:${hashed(key)}`).toString() ===
            hashed(`${"5020055427641753085"}:${keyHash}`).toString()
          ) {
            authorized = true;
          }

          userId = user;
          secretCounter++;
        }

        if (cookie.token.value) {
          const verification = await jwt.verify(cookie.token.value);

          if (verification) {
            authorized = verification.authorized == "y";
            userId = verification.userId.toString();
          } else {
            cookie.token.remove();
          }
        } else {
          cookie.token.value = await jwt.sign({
            userId,
            authorized: authorized ? "y" : "n",
          });
        }

        return { userId, keyHash, authorized };
      })
      .get(
        "/",
        async ({ layout, home, userId, keyHash }) => {
          const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

          $("#user").html(userId);
          $("#coordinates").html(keyHash);
          $(".link").removeClass("has-text-link");
          $("#home-link").addClass("has-text-link");

          $("#content").html(await home().text());
          return $.html();
        },
        {
          headers: t.Object({
            user: t.Optional(t.String()),
          }),
          cookie: t.Cookie({
            user: t.Optional(t.String()),
          }),
        }
      )
      .get("/satellites", async ({ layout, satellites, userId, keyHash }) => {
        const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

        $("#user").html(userId);
        $("#coordinates").html(keyHash);
        $(".link").removeClass("has-text-link");
        $("#satellites-link").addClass("has-text-link");

        $("#content").html(await satellites().text());
        return $.html();
      })
      .get("/salad", async ({ layout, salad, userId, keyHash }) => {
        const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

        $("#user").html(userId);
        $("#coordinates").html(keyHash);
        $(".link").removeClass("has-text-link");

        $("#content").html(await salad().text());
        return $.html();
      })
      .get("/tracking", async ({ layout, tracking, userId, keyHash }) => {
        const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

        $("#user").html(userId);
        $("#coordinates").html(keyHash);
        $(".link").removeClass("has-text-link");
        $("#tracking-link").addClass("has-text-link");

        $("#content").html(await tracking().text());
        return $.html();
      })
      .get("/system", async ({ layout, system, userId, keyHash }) => {
        const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

        $("#user").html(userId);
        $("#coordinates").html(keyHash);
        $(".link").removeClass("has-text-link");
        $("#system-link").addClass("has-text-link");

        $("#content").html(await system().text());
        return $.html();
      })
      .get("/about", async ({ layout, about, userId, keyHash, authorized }) => {
        const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

        $("#user").html(userId);
        $("#coordinates").html(keyHash);
        $(".link").removeClass("has-text-link");
        $("#about-link").addClass("has-text-link");

        $("#content").html(await about().text());

        if (authorized) {
          $("#explore").append(
            `<a class="button is-info is-light" href="/flag" id="flag-link">Beam Flag from Satellite </a>`
          );
        }
        return $.html();
      })
      .get(
        "/flag",
        async ({ layout, flagPage, userId, keyHash, authorized, redirect }) => {
          if (!authorized) return redirect("/");

          const $ = cheerio.load(Buffer.from(await layout().arrayBuffer()));

          $("#user").html(userId);
          $("#coordinates").html(keyHash);
          $(".link").removeClass("has-text-link");
          $("#flag-link").addClass("has-text-link");

          $("#content").html(await flagPage().text());
          $("#flag").html(flag);
          return $.html();
        }
      )
      .post(
        "/hash",
        ({ body }) => {
          return {
            hash: body.data.includes(", ")
              ? body.data.split(", ").map((x) => hashed(x))
              : hashed(body.data),
          };
        },
        {
          body: t.Object({
            data: t.String(),
          }),
        }
      )
      .get("/*", ({ redirect }) => redirect("/"))
);

// Start App
const port = process.env.APP_PORT || 8000;
app.listen(port);

console.log(`Launching Satellite on port: ${port}`);
